from flask import Flask, render_template, request
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.datasets import imdb
import numpy as np

app = Flask(__name__)

# =========================
# Model Settings (MUST MATCH TRAINING)
# =========================
max_features = 10000   # same as training
maxlen = 200           # same as training

# =========================
# Load Trained Model
# =========================
model = tf.keras.models.load_model("imdb_rnn_model.h5")

# =========================
# Load IMDB Word Index
# =========================
word_index = imdb.get_word_index()

# Add reserved tokens (same as IMDB internal format)
word_index = {k: (v + 3) for k, v in word_index.items()}
word_index["<PAD>"] = 0
word_index["<START>"] = 1
word_index["<UNK>"] = 2
word_index["<UNUSED>"] = 3


# =========================
# Text Encoding Function
# =========================
def encode_review(text):
    words = text.lower().split()
    sequence = []

    for word in words:
        index = word_index.get(word, 2)  # 2 = <UNK>

        # 🔥 IMPORTANT: limit to max_features
        if index >= max_features:
            index = 2  # replace with <UNK>

        sequence.append(index)

    return pad_sequences([sequence], maxlen=maxlen)


# =========================
# Routes
# =========================
@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    review = request.form["review"]

    encoded_review = encode_review(review)

    prediction = model.predict(encoded_review)[0][0]

    sentiment = "Positive 😊" if prediction > 0.5 else "Negative 😞"

    confidence = round(float(prediction) * 100, 2)

    return render_template(
        "index.html",
        review=review,
        sentiment=sentiment,
        confidence=confidence
    )


# =========================
# Run App
# =========================
if __name__ == "__main__":
    app.run(debug=True)